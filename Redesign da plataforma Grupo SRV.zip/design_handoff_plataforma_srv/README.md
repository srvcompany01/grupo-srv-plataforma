# Handoff: Redesign da interface logada — Plataforma Grupo SRV

## Visão geral
Redesenho da área logada da plataforma operacional interna do Grupo SRV (agência de marketing, Belém). SaaS de produtividade de uso diário: tarefas e posts por cliente, calendário editorial, chat, agenda e visão de clientes. Objetivo: uma única densidade e um único sistema visual em todos os módulos, tema claro (principal) e escuro, responsivo.

**Nenhuma funcionalidade existente deve ser removida.** Botões podem mudar de lugar conforme este documento. Páginas públicas (blog, página da bio, quiz, relatório do cliente, portal) **não** fazem parte deste redesenho.

## Sobre os arquivos de design
Os arquivos deste pacote são **referências de design feitas em HTML** — protótipos que mostram aparência e comportamento pretendidos, **não código de produção para copiar**. A tarefa é **recriar estes designs no ambiente existente do código** (React, Vue etc.), usando os padrões, componentes e bibliotecas que o projeto já tem. Os dados do protótipo são fictícios; ligue cada tela às APIs reais.

- `SRV Plataforma.dc.html` — protótipo navegável (abre direto no navegador; depende de `support.js` na mesma pasta). Tweaks (painel do editor): `tema` (claro/escuro), `estado` (normal/carregando/vazio), `previewMobile`.
- `Sistema de Design.dc.html` — documentação visual: tokens, tipografia, medidas, componentes, estados, responsivo.
- `tokens.css` — todas as variáveis prontas para colar no CSS global.

## Fidelidade
**Alta fidelidade (hi-fi).** Cores, tipografia, alturas, espaçamentos, raios e interações são finais. Recrie pixel a pixel com os componentes do projeto.

---

## Design tokens
Ver `tokens.css` (fonte da verdade). Resumo:

**Cores (claro / escuro)**
| Token | Claro | Escuro | Uso |
|---|---|---|---|
| --bg | #ffffff | #161618 | conteúdo, cartões |
| --bg-frame | #efeff1 | #0c0c0e | moldura atrás dos painéis flutuantes, topo |
| --bg-subtle | #f7f7f8 | #111113 | painel lateral, cabeçalhos de tabela |
| --bg-hover | #f0f0f2 | #202023 | hover |
| --bg-active | #e8e8eb | #28282c | item ativo, pressionado, tarefa aberta |
| --bg-elev | #ffffff | #1c1c1f | menus, popovers, modais |
| --border / -soft / -strong | #e4e4e7 / #efeff1 / #d1d1d6 | #2a2a2e / #212124 / #3b3b41 | bordas 1px / divisórias de linha / contorno hover |
| --text / -2 / -3 | #18181b / #52525b / #83838c | #ededef / #a8a8b0 / #7a7a83 | texto principal / secundário / metadados |
| --primary / --on-primary | #111113 / #fff | #f4f4f5 / #111113 | botão de ação (preto SRV; invertido no escuro) |
| --rail | #111113 | #0a0a0b | faixa de ícones |
| --red / --red-soft | #d80d12 / #fdeceb | #ff5a5e / #3a1517 | marca, atraso, destrutivo, Modo eu |
| --client / --client-soft | #1d6fe0 / #eaf2fd | #4d8ff0 / #14233a | nome do cliente (sempre negrito 700) |
| --sel | #edf4fe | #15233a | linha selecionada, alvo de arraste |
| --focus / --focus-ring | #1d6fe0 / rgba(29,111,224,.22) | #4d8ff0 / rgba(77,143,240,.3) | foco |

**Status** (iguais nos dois temas): A fazer #8b8b94 · Em produção #e08a00 · Em aprovação #8b5cf6 · Aprovado #16a34a · Publicado #0d9488.
**Prioridade**: Urgente #d80d12 · Alta #e08a00 · Normal #1d6fe0 · Baixa #8b8b94 (ícone bandeira preenchida 15px).

**Tipografia** — fonte do sistema (`-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, Roboto…`).
18/600 título da tarefa · 14/600 título de página · 13/600 título de seção · 13/400 texto e linhas (lh 1.45) · 14/400 mobile e cartões · 12/400 metadados · 11/600 rótulos de seção (MAIÚSCULAS, +0.04em) · 10/500 rótulos da faixa. Números: `font-variant-numeric: tabular-nums`.

**Espaço**: base 4 → 2, 4, 6, 8, 10, 12, 16, 20, 24.
**Alturas**: topo 40 · atalhos fixados 32 · cabeçalho de página 40 · abas 36 · barra de ferramentas 44 · linha 32 (36 em Minhas tarefas/Home) · controle 28 · compacto 24 · mobile 40–44.
**Raio**: 3 checkbox · 4 itens/tags/células · 6 botões/campos · 8 cartões/menus/modais · 10 painéis flutuantes · cápsula só na busca, no Agrupar, em interruptores e reações.
**Sombra**: nenhuma em superfícies. `--shadow-pop` em menus/popovers/modais/barra de lote/toast; `--shadow-panel` no painel da tarefa.
**Movimento**: 120ms hover/cor · 150ms interruptores · 180ms painéis. Sem animação em linhas de lista.
**Ícones**: Material Symbols Rounded (Google Fonts), peso 400. 14 chevrons · 15 abas/propriedades · 16 padrão · 18 faixa. Ícones de aba: quadrado 16×16, raio 4, fundo colorido, glifo 12px branco preenchido.

---

## Casca (todas as telas logadas)

Estrutura desktop (≥768px):
```
┌ Topo 40 (fundo --bg-frame, sem borda) ─────────────────────────────┐
├ Atalhos fixados 32 ────────────────────────────────────────────────┤
│ [Faixa 64]  8  [Painel lateral 256]  8  [Conteúdo flex:1]   8      │  ← padding 0 8 8, gap 8
└────────────────────────────────────────────────────────────────────┘
```
Faixa, painel lateral e conteúdo são **cartões flutuantes**: raio 10, borda 1px --border (a faixa sem borda, fundo --rail). Mobile: sem moldura (padding 0, raio 0).

### Topo — 40px
- Esquerda: botão empresa (logo 20×20 raio 4 #d80d12 "S" branco 11/800 + "Grupo SRV" 13/600 + chevron 14) → menu 240: cabeçalho (logo 28 + nome + "Belém · 24 membros"), Home, Configurações, Gerenciar membros, —, Sair (vermelho). Ícone Agenda 28. Ícone Alertas do sistema 28 (âmbar #e08a00).
- Centro: busca em cápsula `flex: 0 1 360px; min-width 160`, altura 28, raio 14, borda --border, placeholder "Buscar tarefas, clientes, documentos…", kbd "⌘K" (11px, borda, raio 4). Clique ou ⌘K/Ctrl+K abre a paleta.
- Direita (gap 2): "Assistente IA" (secundário, só quando conteúdo ≥1100px) · **Criar** (primário 28: ícone + "Criar") → menu Tarefa (T), Post (P), Documento, Reunião, Lista/pasta/espaço · Minhas tarefas · Reuniões · Documentos (ícones 28) · Sino (ponto 7px #d80d12 com anel 2px) → popover Avisos 340 · Avatar 22 → menu perfil (Meu perfil, Preferências de avisos, Tema escuro [switch], Atalhos ⌘K, Sair).

### Atalhos fixados — 32px (só desktop)
Botões 26 (ícone 15 --text-3 + rótulo 13 --text-2, hover --bg-hover), rolagem horizontal sem barra, "+" ao final fixa a visualização atual. Exemplo: Contas a pagar, Contas a receber, Todos os projetos, Críticos, Todas as atividades, Pipeline comercial, Agenda de reuniões.

### Faixa de ícones — 64px, escura
- Topo: botão 40×32 recolher/mostrar painel lateral (`left_panel_close/open`) + divisória 28×1 rgba(255,255,255,.1).
- Item 56×50, raio 8, coluna: ladrilho 34×28 raio 8 com ícone 18 + rótulo 10/500 (gap 3). Inativo: cor --rail-text, hover --rail-hover e texto branco. **Ativo: ladrilho #d80d12, ícone e rótulo brancos.** Badge: 16px #d80d12, 10/700 branco, anel 2px --rail, canto superior direito do ladrilho.
- Ordem: Início (home), Espaços (grid_view), Chat (chat_bubble, badge), Planejador (event_note), Equipes (groups), Docs (description), Painéis (monitoring), Quadros (draw), Forms (assignment — **só admin**), Mais (more_horiz).
- **Mais** → popover 320 à direita da faixa, grade 2 colunas, itens 32: Clientes, Projetos, Financeiro, Anúncios, Insights, Google Meu Negócio, Performance, Biolytics, Blog, Funis.
- Rodapé: Convidar (person_add), Tema (dark_mode/light_mode), Configurações — 40×36.
- **Reordenável por arraste** (drag & drop HTML5; persistir a ordem por usuário).

### Painel lateral — 256px, recolhível
- Cabeçalho 40: "Início" 14/600 + botão dividido Criar (26+18, borda) + recolher (24).
- Bloco Início: Home, Minhas tarefas (contador), Agenda, Posts, Reuniões (contador). Item 28, padding 0 8, raio 4, ícone 16 --text-2, gap 8. Ativo: --bg-active + 600.
- Seções (rótulo 11/600 MAIÚSCULO --text-3, 28px, recolhível): **Favoritos**, **Espaços** (+ busca e "+" à direita), **Canais**.
- Árvore Espaços › Pastas › Listas: recuo 14/nível a partir de 6. Espaço = quadrado 18 raio 4 cor do espaço + inicial 10/700 branca. Pasta = ícone folder 16. Lista = ponto 7×7 raio 2 na cor do espaço. Chevron 16 para expandir. Contador 12 --text-3 à direita; **no hover o contador vira "⋯" (menu: Renomear, Mover para…, Duplicar, —, Excluir) e "+"** (20×20). **Arraste**: listas soltas em pasta/espaço, pastas soltas em espaço; alvo fica --sel.
- "Novo espaço", Canais (# + nome), "Adicionar canal".
- Rodapé (borda superior): cronômetro 32 (timer + hh:mm:ss tabular 600 + nome da tarefa 12 --text-3 + play/pause 24; ligado = fundo --red-soft, texto --red) · Mensagens diretas (badge) · Personalizar a barra lateral.

---

## Telas

### 1. Lista (tela principal)
**Cabeçalho de página 40** (padding 0 10 0 12, borda inferior --border-soft):
caminho em botões 24 (13px --text-2): [ícone espaço] Produção / [pasta azul] Social Media / [círculo] **Calendário Novembro** (14/600) · estrela favorito 24 (preenchida #e0a100 quando ativo) · seta 24 → menu Renomear, Duplicar, Copiar link, —, Excluir.
Direita (conteúdo ≥1100px): pilha de avatares 22 (−6px, anel 2px) · **Compartilhar** (secundário → popover 340: link + Copiar, “Quem tem acesso” com papéis) · Campos (popover campos personalizados + Novo campo) · Editar status (popover com status arrastáveis + Adicionar status) · divisória · switch **"Subtarefas são posts"**.
Conteúdo <1100px: só Compartilhar + "⋯" (o restante vai para o menu "⋯").

**Abas 36**: cada aba 36 de altura, padding 0 6, gap 4, ícone em quadrado colorido 16 + rótulo 13. Ativa: sublinhado 2px --text e 600. Ordem: Canal, Lista, Calendário, Quadro, Tabela, Galeria, Linha do tempo, Carga de trabalho, Atividade, Painel, Documentos · divisória · "+ Visualização".

**Barra de ferramentas 44**: região rolável (flex:1) + **"+ Tarefa ▾" fixo à direita** (primário 28 + seta 24 → Tarefa, A partir de modelo, Importar CSV).
- Esquerda: **Agrupar** (cápsula 26, borda, --bg-subtle, ícone layers + valor) → Status, Mês, Prioridade, Cliente, Responsável, Etiqueta, Formato (campo personalizado) · expandir/recolher subtarefas · Colunas.
- Direita: **Filtro** (ativo: --bg-active + contador 16 --primary) → popover 360: chips Status, Prioridade, Tag do cliente (alternáveis, ativo --sel + borda --client), linhas Responsável / Etiqueta / Vencimento / Mês, "Limpar" · busca 176 (≥1100px) · **Salvos** → popover: segmentado E/OU (lógica entre facetas), filtros salvos, "Salvar filtro atual" · **Modo eu** (ativo: --red-soft / --red; filtra responsável = usuário) · Personalizar visualização (switches de colunas) · Salvar visualização · divisória · Novo post (secundário).

**Lista agrupada**:
- Cabeçalho de grupo 32: chevron 20 · selo 22 (11/600 MAIÚSCULO +0.03em, padding 0 8 0 6, raio 4; cor sólida do status com texto branco; "A fazer" só contorno --border-strong) com círculo 10 · contador 12 --text-3 · "+" 22. Margem 10 entre grupos. Recolhível.
- Cabeçalho de colunas 28 (11/500 --text-3, borda inferior --border).
- **Grade** (`display:grid`): seleção 28 · subtarefas 20 · círculo de status 24 · Nome `minmax(300px,1fr)` · Responsável 92 · Objetivo 112 · Mês 72 · Status 136 · Vencimento 100 · Formato 96 · Prioridade 96 · "+" 36. Largura mínima = soma; **acima disso rolagem horizontal**.
- Linha 32, divisória --border-soft, hover --bg-hover, selecionada --sel, aberta no painel --bg-active.
  - Checkbox 14 raio 3 (marcado = --primary + check 12 --on-primary).
  - Seta de subtarefas (chevron 16) só se houver subtarefas.
  - Círculo de status 14, borda 2px na cor do status (preenchido em Aprovado/Publicado); clique → menu de status.
  - Título 13 (sublinhado no hover; clique abre Tarefa) + **tag do cliente** (18px, padding 0 6, raio 4, --client-soft, --client, 12/700) + "↳ 1/3" de subtarefas.
  - **Células editáveis**: área 28 raio 4; hover = `box-shadow: inset 0 0 0 1px var(--border-strong)`; clique abre menu de opções (Status, Prioridade, Objetivo, Mês, Formato, Vencimento [Hoje, Amanhã, Próxima segunda, Sexta que vem, Sem vencimento], Responsáveis [multi]). Vencido = --red. Status na célula: pílula 20 com fundo `color-mix(in srgb, COR 16%, transparent)`, ponto 6, texto --text.
- Subtarefas: mesma grade, conteúdo a partir da coluna 3, recuo 18, ícone (photo_library se "Subtarefas são posts", senão subdirectory_arrow_right), círculo 12 (clique alterna concluída), pílula de status e vencimento à direita.
- **"Adicionar tarefa"** 32 (recuo 50, --text-3) → vira campo 28 com foco (Enter salva no grupo, Esc cancela).
- **Edição em lote**: barra flutuante 40, --primary, raio 8, centralizada a 20px do rodapé: "N selecionadas" · Selecionar tudo · Status · Responsável · Vencimento · Prioridade · Duplicar · Excluir (vermelho) · ×. Menus abrem para cima.

**Calendário**: mês (seg→dom), cabeçalho 36 (mês 14/600, ‹ › Hoje, switch "Mostrar subtarefas"), dias `minmax(104px,1fr)`, número 20 (hoje: círculo #d80d12 texto branco), dias fora do mês --bg-subtle. Chips 22 (ponto de status 6 + título 12, borda, raio 4; subtarefa com ícone ↳). **Tarefas-mãe e subtarefas arrastáveis entre dias** (atualiza vencimento; dia-alvo --sel). Coluna direita 252 (--bg-subtle): **Em atraso** (cartões com cliente + data vermelha) e **Sem vencimento** (soltar aqui remove a data).

**Quadro**: colunas por status 272 (--bg-subtle, raio 8; alvo --sel), cabeçalho 40 com selo + contador + "+". Cartão: borda, raio 8, padding 10, gap 8: título 13, tag do cliente, linha com vencimento (ícone event 14), subtarefas, bandeira de prioridade, avatares 20. **Arrastar entre colunas muda o status.** "Adicionar tarefa" 32 ao final.

**Carga de trabalho**: próximos 14 dias, capacidade 8h/dia. Grade `220px repeat(14, minmax(0,1fr))`, cabeçalho 40 (dia da semana 10 + número 13/600; hoje vermelho), linha 44 por pessoa (avatar 22 + nome + total/80h). Célula: bloco raio 4 com horas — ≤5h --ok-soft/--ok, 6–8h --warn-soft/--warn, >8h --red-soft/--red. Fins de semana --bg-subtle vazios. Tooltip com as tarefas do dia.

**Canal** (aba): ver Chat abaixo (mesmo componente), com barra de visualizações vinculadas no rodapé.

**Demais abas** (Tabela, Galeria, Linha do tempo, Atividade, Painel, Documentos): fora deste escopo — mostrar estado vazio padrão.

### 2. Tarefa aberta (painel lateral)
Desktop: `position:absolute; top:72px; right:8px; bottom:8px; width:min(580px, calc(100% - 16px))` (faixa 480–620), raio 10, borda, `--shadow-panel`. **A lista continua interativa atrás.** Esc fecha.
1. Barra 40: caminho 12 --text-3 ("Calendário Novembro / SRV-001") · cronômetro (secundário 28 com play/pause + hh:mm:ss; ligado --red-soft/--red) · copiar link · ⋯ (Duplicar, Mover para lista, Excluir) · fechar.
2. Status: botão 26 sólido na cor do status (11/600 MAIÚSCULO + chevron → menu) + botão 26 "›" que avança para o próximo status · código à direita.
3. **Título editável** 18/600 (input sem borda; hover borda --border; foco --focus + anel).
4. Propriedades em grade `108px 1fr 108px 1fr` (mobile `104px 1fr`), linhas 30, rótulo com ícone 15 --text-2: Responsáveis (avatares + "+" → menu multi), Datas (início → vencimento), Prioridade, Etiquetas (chips 20 --bg-active), Cliente (tag), Objetivo, Formato, Mês, Tempo. Valores são botões 28 com hover --bg-hover que abrem menus.
5. Descrição: textarea min 76, borda, raio 6, foco com anel.
6. Subtarefas (rótulo vira "Posts (subtarefas)" quando o switch está ativo): contador + barra de progresso 64×4 (#16a34a); lista com bordas, linhas 32 (círculo 14 alterna concluída → riscado), campo "Adicionar subtarefa" (Enter).
7. Anexos: linhas 44 (ícone 28 em --bg-active, nome, "tamanho · autor · data", download) + área de soltar 40 tracejada.
8. Abas 32 Comentários · N / Atividade (sublinhado 2px). Comentários: avatar 24, nome 600 + hora, texto 13/1.5, **menções em --client 600**. Atividade: ícone 15 + texto 12 + data.
9. Compositor fixo no rodapé: textarea 2 linhas, barra (anexar, @) + "Comentar". **Enter envia, Shift+Enter quebra linha, "@" abre lista de menção** (popover 240 acima).
Mobile: tela cheia, seta voltar 36.

### 3. Home
Cabeçalho 40 (Home + data à direita). Container max 1240, padding 16 20 48, gap 16.
- Frase de contexto 13 --text-2.
- Blocos de resumo: grade `repeat(auto-fit, minmax(170px,1fr))` gap 8; cartão borda raio 8 padding 10 12: rótulo 12 --text-2, valor 20/600 tabular, meta 12 --text-3. Clicáveis: Minhas tarefas abertas → Minhas tarefas; Em atraso (valor vermelho) → Calendário; Aguardando aprovação → Lista filtrada; Reuniões hoje → Reuniões.
- Grade `1.7fr | minmax(300px,1fr)`:
  - **Panorama dos clientes**: cabeçalho 40 + "Ver Clientes"; tabela (min 680, rolagem) colunas Cliente (azul negrito) · Responsável · Abertas · Em atraso (vermelho se >0) · Aprovação · Próx. entrega · Progresso do mês (barra 4px --text + %). Linha 36 → detalhe do cliente.
  - **Agenda de hoje** (hora 12/600 tabular + título com cliente em azul negrito + meta) e **Minhas tarefas** (linhas 36: círculo, título, cliente, vencimento).

### 4. Minhas tarefas
Cabeçalho 40: título + "N abertas · N em atraso" + switch "Mostrar publicadas" + "+ Tarefa". Grupos por vencimento: **Em atraso** (rótulo vermelho), Hoje, Amanhã, Esta semana, Próximas, Sem vencimento — recolhíveis. Linha 36, grade `28px minmax(240px,1fr) 200px 136px 90px 96px` (status · título+cliente · caminho da lista · pílula de status · vencimento · prioridade), células editáveis como na Lista. Mobile: `28px 1fr 64px`.

### 5. Agenda
Cabeçalho 40: "26 out – 1 nov 2026", ‹ › Hoje, legenda (Reunião #7c3aed · Captação #e08a00 · Interno #71717a) e segmentado Dia/**Semana**/Mês (≥1100px), "+ Reunião". Grade `52px repeat(7, minmax(0,1fr))`, min 760. Cabeçalho fixo 48 (dia 11 MAIÚSCULO + número 24, hoje em círculo vermelho) + linha "Tarefas" com chips das tarefas do usuário que vencem no dia. Corpo 7h–19h, **44px por hora**, linhas de hora --border-soft. Evento: absoluto (top = (início−7)×44, altura = duração×44−3), borda `color-mix(COR 45%)`, fundo `color-mix(COR 16%)`, raio 6: ponto + título 12/600, cliente 11/700 azul, horário 11. **Linha "agora" 2px #d80d12** com bolinha 8.

### 6. Chat
Coluna de conversas 240 (≥1100px; --bg-subtle): cabeçalho 40 "Chat" + nova mensagem, busca 28, **Canais** (# + nome; não lidas = 600 + badge vermelho), **Mensagens diretas** (avatar 20 com presença 8: online #16a34a). Conversa: cabeçalho 40 (# nome 14/600, membros, chamada, fixadas, membros).
Mensagens: avatar 32, nome 13/600 + hora 11 --text-3, linhas 13/1.55; hover da mensagem --bg-hover raio 6. **Menção**: fundo --client-soft, texto --client 600, padding 0 3, raio 3. **Divisor de dia**: linha + cápsula 24 "Hoje ▾". **Fio**: avatares 18 + "N respostas" (--client 600) + "Última resposta há …". **Reação**: cápsula 24 (ativa --red-soft/--red). **Chamada em andamento**: cartão 52, ícone em círculo --ok-soft, botão "Entrar" #d80d12. Anexo de imagem 300×160. Link de documento: botão 24 com ícone verde. "Fulano está digitando…" 12 --text-3.
**Compositor** (fixo no rodapé, raio 8): textarea → barra 38: "+" (círculo 26), seletor **Mensagem/Tarefa/Post**, ferramentas 26 (emoji, anexo, @, atribuir, código, IA, áudio), "Enviar". Enter envia. Abaixo: barra 36 de visualizações vinculadas (ícone 15 + rótulo 13).

### 7. Cliente (detalhe)
Cabeçalho 40: "Clientes / **Nome**" (azul 14/700) + Ver tarefas · Relatório do cliente (abre a página pública — fora do redesenho) · + Tarefa. Abas sublinhadas: Visão geral, Tarefas (→ Lista filtrada pelo cliente), Posts, Relatório, Arquivos, Acessos. Lista de clientes à esquerda 220 (nome azul negrito + abertas). Visão geral (max 1100): 4 indicadores (Posts no mês, Aprovados ou publicados, Em atraso, Alcance 30 dias) · grade `1.6fr | minmax(260px,1fr)`: Entregas do mês (linhas 36) + Entregas por semana (barras planejado --bg-active vs entregue --text, 20px por unidade) | Dados do cliente (Responsável, Segmento, Plano, Cliente desde, Contato, Instagram, Investimento) · Próximas reuniões · Links.

### Paleta de comandos (⌘K / Ctrl+K)
Véu rgba(10,10,12,.35); caixa 600, 72px do topo, raio 8. Campo 48 (ícone 18, 14px, "Esc"). Grupos (11/600 --text-3): Ações, Ir para, Recentes / Tarefas (com cliente em azul). Itens 32; ↑↓ navegam, Enter executa, hover define o ativo. Rodapé 32 com atalhos.

---

## Componentes (medidas)
- **Botões**: 28 (24 compacto, 40–44 mobile); padding 0 10 (com ícone 0 10 0 6), gap 4–6, raio 6. Primário --primary/600; secundário borda --border + --bg; fantasma transparente --text-2; ícone 28×28; destrutivo --red-soft/--red. Hover --primary-hover ou --bg-hover. Foco: anel 3px --focus-ring (`:focus-visible`).
- **Campos**: 28 (32 em modais, 40 mobile), padding 0 8, raio 6. Foco: borda --focus + anel 3px. Rótulo 12/600 --text-2, ajuda/erro 12.
- **Switch** 28×16 raio 8, bolinha 12 --bg, ligado --primary, desligado --border-strong, 150ms. **Checkbox** 14 raio 3.
- **Menu**: 200–260, padding 4, raio 8, --bg-elev, borda, --shadow-pop. Item 30 (40 mobile), padding 0 8, raio 4, ícone 16 --text-2; título 11/600; divisória sangrando 4px; destrutivo por último em --red; marcado = check à direita.
- **Popover**: 340–360, padding 12, gap 10.
- **Posicionamento**: a 4px do gatilho, alinhado à esquerda (ou à direita para gatilhos da metade direita); abre para cima se faltar 300px abaixo; menu "Mais" abre ao lado da faixa. Fecha em clique fora ou Esc.
- **Toast**: 36, --primary, raio 6, canto inferior esquerdo, 2,2s.
- **Cartões**: borda 1px, raio 8, padding 10 12, sem sombra; hover borda --border-strong. Seção com cabeçalho 40 (13/600 + ação à direita).

## Estados
- **Hover**: --bg-hover, 120ms (na árvore revela ⋯ e +; em células, contorno interno --border-strong).
- **Foco**: borda --focus + anel 3px --focus-ring.
- **Selecionado**: --sel (linhas marcadas, alvos de arraste); ativo na navegação: --bg-active + 600; tarefa aberta: --bg-active.
- **Vazio**: centralizado — ícone 20 em caixa 40 com borda raio 8, título 14/600, texto 13 --text-2 (máx 320), uma ação primária 28. Casos: lista vazia (+ Tarefa), nenhum resultado (Limpar filtros), visualização não configurada, canal sem mensagens.
- **Carregando**: esqueleto com a mesma altura da linha real (círculo 14 + barras 10px --skel), pulso 1,2s. Nunca spinner de tela cheia.

## Responsivo (<768px)
- Faixa + painel saem do fluxo; **hambúrguer 36** abre gaveta (64+256) sobre véu rgba(10,10,12,.45).
- Topo: busca vira ícone 36; Minhas tarefas/Reuniões/Documentos saem do topo; atalhos fixados ocultos.
- Cabeçalho da Lista: nome + estrela + seta + "⋯" (itens 40) com Compartilhar, Campos, Editar status, Subtarefas são posts, Buscar, Salvos, Personalizar, Salvar visualização, Novo post.
- **Tarefas viram cartões verticais**: borda, raio 8, padding 10 12, gap 8 — linha 1: círculo 16 + título 14; linha 2 (recuo 26): tag do cliente, vencimento, prioridade, avatares 22. "Nova tarefa" = botão tracejado 44.
- **Tarefa aberta**: tela cheia, seta voltar, propriedades em uma coluna.
- Breakpoint intermediário: quando a área de conteúdo < 1100px, ações secundárias do cabeçalho/barra/topo colapsam em "⋯" e a coluna de conversas do Chat some.

## Estado (sugestão)
- Global: `theme` (persistir por usuário), `railOrder`, `sidebarCollapsed`, `pinnedViews`, `favorites`, `treeExpanded`, timer `{running, seconds, taskId}`.
- Lista: `view`, `groupBy`, `collapsedGroups`, `filters {status[], prio[], client[], assignee, tag, due, month}`, `filterLogic: 'E'|'OU'`, `savedFilters`, `modoEu`, `search`, `visibleColumns`, `selection`, `expandedTasks`, `subtasksArePosts`.
- Tarefa aberta: `openTaskId`, aba de comentários/atividade, rascunho do comentário.
- Chat: canal ativo, rascunho, modo do compositor (Mensagem/Tarefa/Post).
- Mutações otimistas para status, vencimento, responsáveis e arraste (calendário/quadro/árvore), com rollback em erro.

## Ordem de implementação recomendada
1. `tokens.css` + alternador de tema; remover cores fixas dos componentes atuais.
2. Casca: topo, atalhos fixados, faixa, painel lateral, moldura flutuante, paleta ⌘K.
3. Componentes base: botões, campos, menus/popovers, switch, checkbox, toast, estados vazio/carregando.
4. Lista (grupos, grade, células editáveis, lote, filtros) + Tarefa aberta.
5. Calendário, Quadro, Carga de trabalho, Canal.
6. Home, Minhas tarefas, Agenda, Chat, Cliente.
7. Demais módulos reutilizando cabeçalho 40 / abas 36 / barra 44 / tabela 32.

## Assets
- Ícones: **Material Symbols Rounded** (Google Fonts, `opsz,wght,FILL,GRAD@20,300..500,0..1,0`). Se o projeto já usa outra biblioteca (Lucide, Phosphor etc.), mapeie equivalentes mantendo os tamanhos.
- Logo: o protótipo usa um quadrado vermelho "S" provisório — substituir pelo logo oficial do Grupo SRV.
- Nenhuma imagem; avatares são iniciais sobre cor.

## Arquivos
- `SRV Plataforma.dc.html` — protótipo (requer `support.js` ao lado). Navegue por: Faixa (Início, Espaços, Chat, Mais › Clientes), painel lateral (Minhas tarefas, Agenda), abas da Lista, linhas (abrem Tarefa), ⌘K.
- `Sistema de Design.dc.html` — documentação visual, com alternador de tema.
- `tokens.css` — variáveis CSS.
